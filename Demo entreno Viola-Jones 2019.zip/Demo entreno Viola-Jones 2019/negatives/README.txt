Abril de 2018
A diferencia de versiones previas, para evitar errores al entrenar, he debudo intoducir la ruta absoluta de las im�geens negativas