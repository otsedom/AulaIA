Abril de 2018

- Probado con la versi�n 3.3.1 en Windows. Para la versi�n 3.4.1 en ubuntu retorna un problema con 
createsamples, al parecer conocido. En Windows, la versi�n 3.4.1, me canta un virus al intentar
descomprimir, pero la 3.4 presenta el mismo problema. 

- Como curiosidad, si no indico ruta absoluta en las negativas, da el error: 

�Train dataset for temp stage can not be filled.�

/stackoverflow.com/questions/11412655/error-train-dataset-for-temp-stage-can-not-be-filled-while-using-traincascade

- Para crear archivo con rutas absolutas en Windows (mejor evitar tildes) 
	dir /s/b samples > negs.txt

- No me sucede en la 3.3.1, pero pruebas anteriores no me permit�an indicar el mismo n�mero de positivas al crear y entrenar. No era
as� en versiones previas.

- Versiones anteriores creo que me permit�an crear m�s muestras positivas a partir de un conjunto sin el parse error actual